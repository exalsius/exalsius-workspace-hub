{{/*
Common labels
*/}}
{{- define "gateway-api-inference-extension.labels" -}}
app.kubernetes.io/name: {{ include "gateway-api-inference-extension.name" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- end }}

{{/*
Create a safe resource name that respects Kubernetes naming limits (63 chars).
*/}}
{{- define "gateway-api-inference-extension.safeName" -}}
{{- $base := .base | lower | trim -}}
{{- $suffix := .suffix -}}
{{- $fullSuffix := printf "-%s" $suffix -}}
{{- $maxBaseLength := sub 63 (len $fullSuffix) -}}
{{- if gt (len $base) $maxBaseLength -}}
{{- printf "%s%s" ($base | trunc (int $maxBaseLength)) $fullSuffix -}}
{{- else -}}
{{- printf "%s%s" $base $fullSuffix -}}
{{- end -}}
{{- end -}}

{{/*
Inference extension name
*/}}
{{- define "gateway-api-inference-extension.name" -}}
{{- $base := .Release.Name | default "default-pool" | lower | trim -}}
{{- if and (hasKey .Values "global") (hasKey .Values.global "deploymentName") .Values.global.deploymentName -}}
{{- $base = .Values.global.deploymentName | lower | trim -}}
{{- end -}}
{{- $base = $base | trunc 40 -}}
{{- include "gateway-api-inference-extension.safeName" (dict "base" $base "suffix" "epp") -}}
{{- end -}}

{{/*
Cluster RBAC unique name
*/}}
{{- define "gateway-api-inference-extension.cluster-rbac-name" -}}
{{- $base := .Release.Name | default "default-pool" | lower | trim -}}
{{- if and (hasKey .Values "global") (hasKey .Values.global "deploymentName") .Values.global.deploymentName -}}
{{- $base = .Values.global.deploymentName | lower | trim -}}
{{- end -}}
{{- $base = $base | trunc 40 -}}
{{- $ns := .Release.Namespace | default "default" | lower | trim | trunc 40 }}
{{- printf "%s-%s-epp" $base $ns | quote | trunc 84 }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "gateway-api-inference-extension.selectorLabels" -}}
{{- /* Check if endpointsServer exists AND if createInferencePool is false */ -}}
{{- if and .Values.inferenceExtension.endpointsServer (not .Values.inferenceExtension.endpointsServer.createInferencePool) -}}
{{- /* LOGIC FOR STANDALONE EPP MODE */ -}}
epp: {{ include "gateway-api-inference-extension.name" . }}
{{- else -}}
{{- /* LOGIC FOR PARENT (INFERENCEPOOL) MODE */ -}}
inferencepool: {{ include "gateway-api-inference-extension.name" . }}
{{- end -}}
{{- end -}}

{{/*
Mode labels
*/}}
{{- define "gateway-api-inference-extension.modeLabels" -}}
{{- if and .Values.inferenceExtension.endpointsServer (not .Values.inferenceExtension.endpointsServer.createInferencePool) -}}
inference.networking.k8s.io/igw-mode: standalone
{{- else -}}
inference.networking.k8s.io/igw-mode: inferencepool
{{- end -}}
{{- end -}}
